
public class Deadwood {
	public static void main(String args[]) {
		View board = new View();
		board.setVisible(true);
		Board.setUp();
		Board.SetScenes();
		Board.Game();
	}
}
